import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.application.Application;

public class Snake extends Application{

    @Override
    public void start(Stage primaryStage){

    }


    public static void main(String[] args){
	
    }
}
